<template>
    <div>{{ message }}</div>
</template>
<script>
export default {
    name:"example",
    data(){
        return {
        message:"HI"
        }
    }
    }
</script>
<style></style>